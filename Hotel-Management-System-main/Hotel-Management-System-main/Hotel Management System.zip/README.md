
  # Hotel Management System

  This is a code bundle for Hotel Management System. The original project is available at https://www.figma.com/design/oM1shVOtpq3gRGGu5s0Fws/Hotel-Management-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  